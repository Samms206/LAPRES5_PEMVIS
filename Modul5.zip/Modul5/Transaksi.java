/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul5;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author macbookpro
 */
public class Transaksi extends javax.swing.JInternalFrame {

    /**
     * Creates new form Transaksi
     */
    private ResultSet rs;
    private Statement st;
    private PreparedStatement ps;
    Connection conn = koneksi.Koneksi();
    DefaultTableModel model = new DefaultTableModel();
    String kode_trans = "0";
    public int harga = 0, bayar = 0, kembalian = 0, qty = 0, total = 0;
    
    public Transaksi() {
        initComponents();
        tampil_barang();
        enable_form();
        realtime_totalharga();
        realtime_kembalian();
        tampil_tabel();
    }
    void tampil_tabel(){
        Object[] kolom = {
            "No", "Nama", "kd_brg", "Barang","Harga", "Qty", "Tota", "Dibayar", "Kembalian"
        };
        model = new DefaultTableModel(null, kolom);
        tbl_transaksi.setModel(model);
        try {
          st = conn.createStatement();
          rs = st.executeQuery("SELECT * FROM transaksi");
          while (rs.next()) {
            Object[] data = {
              rs.getString("kode_trans"),
              rs.getString("nama_customer"),
              rs.getString("kode_barang"),
              rs.getString("nama_barang"),
              rs.getString("harga_barang"),
              rs.getString("qty"),
              rs.getString("total_harga"),
              rs.getString("dibayar"),
              rs.getString("kembalian"),
            };
              model.addRow(data);
          }
        } catch(Exception e) {
          e.printStackTrace();
        }
    }
    
    void enable_form(){
        e_kodebarang.setEditable(false);
        e_hargabarang.setEditable(false);
        e_totalharga.setEditable(false);
        e_kembalian.setEditable(false);
        e_bayar.enable(false);
    }
    void reset_form(){
        if (e_customer.getText().equals("") || e_pilihbarang.getSelectedIndex() == 0 
            || e_totalharga.getText().equals("") || e_kembalian.getText().equals("")
            || e_qty.getText().equals("") || e_bayar.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "formnya udah kosong bang");
        }else{
            e_customer.setText("");
            e_pilihbarang.setSelectedIndex(0);
            e_kodebarang.setText("");
            e_hargabarang.setText("");
            e_kembalian.setText("");
            e_totalharga.setText("");
            e_qty.setText("");
            e_bayar.setText("");
            e_qty.setEnabled(true);
            e_bayar.setEnabled(false);
            kode_trans = "0";
        }
    }
    void tampil_barang(){
        try {
            String query = "SELECT no,nama,harga FROM barang";
            st = conn.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                String kode = rs.getString("no");
                String nama = rs.getString("nama");
                String harga = rs.getString("harga");
                e_pilihbarang.addItem(nama);
                e_pilihbarang.addItemListener(new ItemListener() {
                    @Override
                    public void itemStateChanged(ItemEvent e) {
                        if (e.getStateChange() == ItemEvent.SELECTED) {
                            String selectedValue = e_pilihbarang.getSelectedItem().toString();
                            if (selectedValue.equals(nama)) {
                                e_kodebarang.setText(kode);
                                e_hargabarang.setText(harga);
                            }
                        }
                    }
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "error "+e.getMessage());
        }
    }

    private void updateKembalian() {
        harga = Integer.parseInt(e_totalharga.getText());
        e_qty.setEnabled(false);
        try {
            bayar = Integer.parseInt(e_bayar.getText());
        } catch (NumberFormatException ex) {
            // Tambahkan penanganan jika input bayar bukan angka
            JOptionPane.showMessageDialog(this, "Pembayaran harus berisi angka.", "Error", JOptionPane.ERROR_MESSAGE);
            e_bayar.setText(""); // Hapus input yang tidak valid
            return;
        }
        kembalian = bayar - harga;
        e_kembalian.setText(String.valueOf(kembalian));
    }
    
    void realtime_kembalian(){
        e_bayar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateKembalian();
            }
        });
    }
    
    private void updateTotal() {
        e_bayar.enable(true);
        harga = Integer.parseInt(e_hargabarang.getText());
        try {
            qty = Integer.parseInt(e_qty.getText());
        } catch (NumberFormatException ex) {
            // Tambahkan penanganan jika input qty bukan angka
            JOptionPane.showMessageDialog(this, "Kuantitas harus berisi angka.", "Error", JOptionPane.ERROR_MESSAGE);
            e_qty.setText(""); // Hapus input yang tidak valid
            return;
        }
        total = harga * qty;
        e_totalharga.setText(String.valueOf(total));
    }
    
    void realtime_totalharga(){
        e_qty.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateTotal();
            }
        });
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        e_pilihbarang = new javax.swing.JComboBox<>();
        e_customer = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        e_kodebarang = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        e_hargabarang = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        e_totalharga = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        e_kembalian = new javax.swing.JTextField();
        b_reset = new javax.swing.JButton();
        b_simpan = new javax.swing.JButton();
        e_hapus = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_transaksi = new javax.swing.JTable();
        e_qty = new javax.swing.JTextField();
        e_bayar = new javax.swing.JTextField();

        setMaximumSize(new java.awt.Dimension(600, 470));
        setMinimumSize(new java.awt.Dimension(600, 470));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("=====TRANSAKSI=====");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 580, -1));

        jLabel3.setText("Nama Customer");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, -1, -1));

        jLabel4.setText("Pilih Barang");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, -1));

        e_pilihbarang.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "pilih" }));
        e_pilihbarang.addHierarchyListener(new java.awt.event.HierarchyListener() {
            public void hierarchyChanged(java.awt.event.HierarchyEvent evt) {
                e_pilihbarangHierarchyChanged(evt);
            }
        });
        jPanel1.add(e_pilihbarang, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 100, 170, -1));
        jPanel1.add(e_customer, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 60, 160, -1));

        jLabel5.setText("Kode Barang");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, -1, -1));
        jPanel1.add(e_kodebarang, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, 160, -1));

        jLabel6.setText("Harga Barang");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, -1, -1));
        jPanel1.add(e_hargabarang, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 180, 160, -1));

        jLabel7.setText("Qty");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, -1, -1));
        jPanel1.add(e_totalharga, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 60, 160, -1));

        jLabel8.setText("Total Harga");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 60, -1, 20));

        jLabel9.setText("Bayar");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 100, -1, 20));

        jLabel10.setText("Kembalian");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 140, -1, 20));
        jPanel1.add(e_kembalian, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 140, 160, -1));

        b_reset.setText("Reset");
        b_reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_resetActionPerformed(evt);
            }
        });
        jPanel1.add(b_reset, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 220, 120, 40));

        b_simpan.setText("Simpan");
        b_simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_simpanActionPerformed(evt);
            }
        });
        jPanel1.add(b_simpan, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 170, 250, 40));

        e_hapus.setText("Hapus");
        e_hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                e_hapusActionPerformed(evt);
            }
        });
        jPanel1.add(e_hapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 220, 120, 40));

        tbl_transaksi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbl_transaksi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_transaksiMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_transaksi);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, 560, 150));
        jPanel1.add(e_qty, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 220, 160, -1));
        jPanel1.add(e_bayar, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 100, 160, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void e_pilihbarangHierarchyChanged(java.awt.event.HierarchyEvent evt) {//GEN-FIRST:event_e_pilihbarangHierarchyChanged
        // TODO add your handling code here:
        
    }//GEN-LAST:event_e_pilihbarangHierarchyChanged

    private void b_resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_resetActionPerformed
        // TODO add your handling code here:
        reset_form();
    }//GEN-LAST:event_b_resetActionPerformed

    private void b_simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_simpanActionPerformed
        String eqty = e_qty.getText();
        String ebayar = e_bayar.getText();
        if (e_customer.getText().equals("") || e_pilihbarang.getSelectedIndex() == 0 
                || e_totalharga.getText().equals("") || e_kembalian.getText().equals("")
                || e_qty.getText().equals("") || e_bayar.getText().equals("")
                || !eqty.matches("\\d+") || !ebayar.matches("\\d+(\\.\\d+)?")) {
            JOptionPane.showMessageDialog(this, "formnya masih kosong bang/Input Tida Valid");
        }else{
            if (b_simpan.getText().equals("Simpan")) {
                try {
                    String query = "INSERT INTO transaksi"
                        + "(nama_customer, kode_barang, nama_barang, harga_barang, qty, total_harga, dibayar, kembalian) "
                        + "VALUES (?, ? ,?, ?, ?, ?, ?, ?)";
                    ps = conn.prepareStatement(query);
                    ps.setString(1, e_customer.getText());
                    ps.setString(2, e_kodebarang.getText());
                    ps.setString(3, e_pilihbarang.getSelectedItem().toString());
                    ps.setString(4, e_hargabarang.getText());
                    ps.setString(5, e_qty.getText());
                    ps.setString(6, e_totalharga.getText());
                    ps.setString(7, e_bayar.getText());
                    ps.setString(8, e_kembalian.getText());
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(this, "berhasil melakukan transaksi");
                    reset_form();
                    tampil_tabel();
                    e_bayar.setEnabled(true);
                }catch(SQLException e){
                    JOptionPane.showMessageDialog(this, "Eror "+e.getMessage());
                }
            }else{
                try {
                    String query = "UPDATE transaksi SET"
                        + " nama_customer=?, kode_barang=?, nama_barang=?, "
                        + "harga_barang=?, qty=?, total_harga=?, dibayar=?, kembalian=?"
                        + " WHERE kode_trans=?";
                    ps = conn.prepareStatement(query);
                    ps.setString(1, e_customer.getText());
                    ps.setString(2, e_kodebarang.getText());
                    ps.setString(3, e_pilihbarang.getSelectedItem().toString());
                    ps.setString(4, e_hargabarang.getText());
                    ps.setString(5, e_qty.getText());
                    ps.setString(6, e_totalharga.getText());
                    ps.setString(7, e_bayar.getText());
                    ps.setString(8, e_kembalian.getText());
                    ps.setString(9, kode_trans);
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(this, "berhasil mengupdate melakukan transaksi");
                    reset_form();
                    tampil_tabel();
                    
                }catch(SQLException e){
                    JOptionPane.showMessageDialog(this, "Eror "+e.getMessage());
                    System.out.println(e.getMessage());
                }
            }   
        }
    }//GEN-LAST:event_b_simpanActionPerformed

    private void tbl_transaksiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_transaksiMouseClicked
        // TODO add your handling code here:
        b_simpan.setText("Edit");
        int selectedRow = tbl_transaksi.getSelectedRow();
            if (selectedRow != -1) {
                kode_trans = tbl_transaksi.getValueAt(selectedRow, 0).toString();
                e_customer.setText(tbl_transaksi.getValueAt(selectedRow, 1).toString());
                e_kodebarang.setText(tbl_transaksi.getValueAt(selectedRow, 2).toString());
                e_pilihbarang.setSelectedItem(tbl_transaksi.getValueAt(selectedRow, 3).toString());
                e_hargabarang.setText(tbl_transaksi.getValueAt(selectedRow, 4).toString());
                e_qty.setText(tbl_transaksi.getValueAt(selectedRow, 5).toString());
                e_totalharga.setText(tbl_transaksi.getValueAt(selectedRow, 6).toString());
                e_bayar.setText(tbl_transaksi.getValueAt(selectedRow, 7).toString());
                e_kembalian.setText(tbl_transaksi.getValueAt(selectedRow, 8).toString());
            }
    }//GEN-LAST:event_tbl_transaksiMouseClicked

    private void e_hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_e_hapusActionPerformed
        // TODO add your handling code here:
        if (kode_trans.equals("0")) {
            JOptionPane.showMessageDialog(this, "silahkan pilih data terselbih dahulu");
        }else{
            try {
                String query = "DELETE from transaksi"
                    + " WHERE kode_trans=?";
                ps = conn.prepareStatement(query);
                ps.setString(1, kode_trans);
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "berhasil menhapus data transaksi");
                tampil_tabel();
                reset_form();
            }catch(SQLException e){
                JOptionPane.showMessageDialog(this, "Eror "+e.getMessage());
                System.out.println(e.getMessage());
            }
        }
    }//GEN-LAST:event_e_hapusActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b_reset;
    private javax.swing.JButton b_simpan;
    private javax.swing.JTextField e_bayar;
    private javax.swing.JTextField e_customer;
    private javax.swing.JButton e_hapus;
    private javax.swing.JTextField e_hargabarang;
    private javax.swing.JTextField e_kembalian;
    private javax.swing.JTextField e_kodebarang;
    private javax.swing.JComboBox<String> e_pilihbarang;
    private javax.swing.JTextField e_qty;
    private javax.swing.JTextField e_totalharga;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbl_transaksi;
    // End of variables declaration//GEN-END:variables
}
